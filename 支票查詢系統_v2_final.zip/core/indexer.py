"""
索引管理模組
負責掃描 PDF、建立支票號碼索引、快取管理

索引結構說明：
- 每個 PDF 對應一個 {pdfname}.json（增量更新用）
- master_index.json 是所有 PDF 的合併索引（查詢用）

索引格式：
{
  "HF1377789": {
    "file": "20260320.pdf",
    "page": 4,             # 0-based 頁碼
    "position": "top",     # "full" / "top" / "bottom"
    "raw_ocr": "HF1377789",
    "indexed_at": "2026-03-20T10:00:00"
  }
}

設計考量：
- 同一支票號碼若出現在多個位置，全部記錄（回傳列表）
- 無法辨識的頁面標記為 unrecognized，避免重複掃描
- 使用檔案修改時間判斷是否需要重新索引
"""
import json
import hashlib
import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Callable

import fitz  # PyMuPDF
import numpy as np
from PIL import Image

logger = logging.getLogger(__name__)

# 索引資料格式版本（未來若格式改變可做相容性處理）
INDEX_FORMAT_VERSION = "1.1"

# 單一頁面最多可能含幾張支票（防呆）
MAX_CHECKS_PER_PAGE = 2


class CheckEntry:
    """單筆支票索引記錄"""

    __slots__ = ['file', 'page', 'position', 'raw_ocr', 'indexed_at']

    def __init__(self, file: str, page: int, position: str,
                 raw_ocr: str = '', indexed_at: str = ''):
        self.file = file          # 原始 PDF 檔名（不含路徑）
        self.page = page          # 0-based 頁碼
        self.position = position  # 'full' / 'top' / 'bottom'
        self.raw_ocr = raw_ocr    # OCR 原始輸出
        self.indexed_at = indexed_at or datetime.now().isoformat()

    def to_dict(self) -> dict:
        return {
            'file': self.file,
            'page': self.page,
            'position': self.position,
            'raw_ocr': self.raw_ocr,
            'indexed_at': self.indexed_at,
        }

    @staticmethod
    def from_dict(d: dict) -> 'CheckEntry':
        return CheckEntry(
            file=d['file'],
            page=d['page'],
            position=d['position'],
            raw_ocr=d.get('raw_ocr', ''),
            indexed_at=d.get('indexed_at', ''),
        )


class Indexer:
    """
    支票索引管理器
    
    使用方式：
        indexer = Indexer(config)
        indexer.load()  # 載入既有索引
        indexer.build_all(ocr_engine, progress_cb)  # 全量建立索引
        entries = indexer.get_entries('HF1377789')  # 查詢
    """

    def __init__(self, config):
        from config import Config
        self._config = config
        # 主索引：{check_number: [CheckEntry, ...]}
        self._master: Dict[str, List[CheckEntry]] = {}
        # 已索引 PDF 的元資料：{filename: {mtime, page_count, indexed_at}}
        self._pdf_meta: Dict[str, dict] = {}
        # 無法辨識的頁面（不重複掃描）
        self._unrecognized: Dict[str, List[int]] = {}  # {filename: [page_indices]}

    # ─── 公開 API ────────────────────────────────────────

    def load(self) -> int:
        """
        載入既有索引。
        Returns: 已索引支票數量
        """
        index_dir = self._config.index_dir
        if not index_dir:
            return 0

        master_file = index_dir / 'master_index.json'
        if not master_file.exists():
            logger.info("找不到主索引，需要建立")
            return 0

        try:
            with open(master_file, 'r', encoding='utf-8') as f:
                data = json.load(f)

            # 版本相容性檢查
            version = data.get('version', '1.0')
            logger.info(f"載入索引版本: {version}")

            # 還原主索引
            self._master = {}
            for check_num, entries_data in data.get('entries', {}).items():
                if isinstance(entries_data, list):
                    self._master[check_num] = [
                        CheckEntry.from_dict(e) for e in entries_data
                    ]
                else:
                    # 舊格式相容
                    self._master[check_num] = [CheckEntry.from_dict(entries_data)]

            # 還原 PDF 元資料
            self._pdf_meta = data.get('pdf_meta', {})
            self._unrecognized = data.get('unrecognized', {})

            count = len(self._master)
            logger.info(f"成功載入索引：{count} 筆支票號碼")
            return count

        except (json.JSONDecodeError, KeyError, OSError) as e:
            logger.error(f"載入索引失敗: {e}")
            self._master = {}
            return 0

    def save(self):
        """儲存主索引到共用資料夾"""
        index_dir = self._config.index_dir
        if not index_dir:
            logger.error("未設定共用資料夾，無法儲存索引")
            return False

        try:
            index_dir.mkdir(parents=True, exist_ok=True)

            data = {
                'version': INDEX_FORMAT_VERSION,
                'created_at': datetime.now().isoformat(),
                'total_checks': len(self._master),
                'entries': {
                    check_num: [e.to_dict() for e in entries]
                    for check_num, entries in self._master.items()
                },
                'pdf_meta': self._pdf_meta,
                'unrecognized': self._unrecognized,
            }

            master_file = index_dir / 'master_index.json'
            # 先寫到臨時檔案再替換（防止同時讀寫損壞）
            tmp_file = master_file.with_suffix('.tmp')
            with open(tmp_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            tmp_file.replace(master_file)

            logger.info(f"索引已儲存：{len(self._master)} 筆")
            return True

        except OSError as e:
            logger.error(f"儲存索引失敗: {e}")
            return False

    def get_pdf_list(self) -> List[Path]:
        """取得 PDF 目錄下的所有 PDF 檔案"""
        pdf_dir = self._config.pdf_dir
        if not pdf_dir or not pdf_dir.exists():
            return []
        try:
            return sorted(pdf_dir.glob('*.pdf'))
        except OSError as e:
            logger.error(f"無法讀取 PDF 目錄: {e}")
            return []

    def get_new_pdfs(self) -> List[Path]:
        """
        取得尚未索引或已更新的 PDF 檔案
        （比對檔案修改時間）
        """
        all_pdfs = self.get_pdf_list()
        new_pdfs = []
        for pdf_path in all_pdfs:
            name = pdf_path.name
            mtime = pdf_path.stat().st_mtime
            if name not in self._pdf_meta:
                new_pdfs.append(pdf_path)
            elif self._pdf_meta[name].get('mtime', 0) != mtime:
                logger.info(f"PDF 已更新，需重新索引: {name}")
                new_pdfs.append(pdf_path)
        return new_pdfs

    def build_all(
        self,
        ocr_engine,
        progress_callback: Optional[Callable] = None,
        cancel_flag: Optional[list] = None
    ) -> Tuple[int, int, List[str]]:
        """
        全量掃描所有 PDF 並建立索引
        
        Args:
            ocr_engine: OCREngine 實例
            progress_callback: callback(current, total, message)
            cancel_flag: [False]，設為 [True] 可中途取消
        
        Returns:
            (新增支票數, PDF數量, 錯誤清單)
        """
        pdf_list = self.get_pdf_list()
        if not pdf_list:
            return 0, 0, ["PDF 目錄中沒有找到 PDF 檔案"]

        new_check_count = 0
        errors = []
        total = len(pdf_list)

        for i, pdf_path in enumerate(pdf_list):
            # 中途取消
            if cancel_flag and cancel_flag[0]:
                logger.info("使用者取消索引建立")
                break

            if progress_callback:
                progress_callback(i, total, f"正在掃描：{pdf_path.name}")

            try:
                count = self._index_pdf(pdf_path, ocr_engine,
                                        progress_callback, cancel_flag, i, total)
                new_check_count += count
                logger.info(f"{pdf_path.name}: 找到 {count} 張支票")
            except Exception as e:
                msg = f"{pdf_path.name}: 掃描失敗 - {e}"
                errors.append(msg)
                logger.error(msg)

        # 儲存索引
        if not (cancel_flag and cancel_flag[0]):
            if progress_callback:
                progress_callback(total, total, "正在儲存索引...")
            self.save()

        return new_check_count, total, errors

    def build_incremental(
        self,
        ocr_engine,
        progress_callback: Optional[Callable] = None,
        cancel_flag: Optional[list] = None
    ) -> Tuple[int, int, List[str]]:
        """
        增量掃描（只掃描新增或已更新的 PDF）
        """
        new_pdfs = self.get_new_pdfs()
        if not new_pdfs:
            return 0, 0, []

        new_check_count = 0
        errors = []
        total = len(new_pdfs)

        for i, pdf_path in enumerate(new_pdfs):
            if cancel_flag and cancel_flag[0]:
                break

            if progress_callback:
                progress_callback(i, total, f"掃描新增 PDF：{pdf_path.name}")

            try:
                # 先移除舊記錄
                self._remove_pdf_from_index(pdf_path.name)
                count = self._index_pdf(pdf_path, ocr_engine,
                                        progress_callback, cancel_flag, i, total)
                new_check_count += count
            except Exception as e:
                msg = f"{pdf_path.name}: {e}"
                errors.append(msg)
                logger.error(msg)

        if not (cancel_flag and cancel_flag[0]):
            self.save()

        return new_check_count, total, errors

    def get_entries(self, check_number: str) -> List[CheckEntry]:
        """
        查詢支票號碼，回傳所有符合的記錄
        （大小寫不敏感）
        """
        key = check_number.upper().strip()
        return self._master.get(key, [])

    def search_fuzzy(self, query: str) -> List[Tuple[str, List[CheckEntry]]]:
        """
        模糊搜尋：回傳所有包含 query 的支票號碼
        Returns: [(check_number, [entries]), ...]
        """
        query = query.upper().strip()
        if not query:
            return []

        results = []
        for check_num, entries in self._master.items():
            if query in check_num:
                results.append((check_num, entries))

        # 依支票號碼排序
        results.sort(key=lambda x: x[0])
        return results

    @property
    def total_checks(self) -> int:
        return len(self._master)

    @property
    def indexed_pdf_count(self) -> int:
        return len(self._pdf_meta)

    def get_stats(self) -> dict:
        """取得索引統計資料"""
        return {
            'total_checks': len(self._master),
            'total_pdfs': len(self._pdf_meta),
            'unrecognized_pages': sum(
                len(v) for v in self._unrecognized.values()
            ),
            'pdf_list': list(self._pdf_meta.keys()),
        }

    # ─── 私有方法 ────────────────────────────────────────

    def _index_pdf(
        self,
        pdf_path: Path,
        ocr_engine,
        progress_callback,
        cancel_flag,
        base_i: int,
        base_total: int
    ) -> int:
        """
        索引單一 PDF 檔案
        Returns: 找到的支票數量
        """
        count = 0
        pdf_name = pdf_path.name
        unrecognized_pages = []

        try:
            doc = fitz.open(str(pdf_path))
        except Exception as e:
            raise RuntimeError(f"無法開啟 PDF: {e}")

        try:
            total_pages = doc.page_count
            mtime = pdf_path.stat().st_mtime

            for page_idx in range(total_pages):
                if cancel_flag and cancel_flag[0]:
                    return count

                if progress_callback and page_idx % 10 == 0:
                    progress_callback(
                        base_i, base_total,
                        f"掃描 {pdf_name} 第 {page_idx+1}/{total_pages} 頁..."
                    )

                # 將頁面渲染為圖片
                page_image = self._render_page(doc, page_idx,
                                               self._config.index_dpi)
                if page_image is None:
                    unrecognized_pages.append(page_idx)
                    continue

                # 嘗試辨識上半部支票
                top_number = ocr_engine.extract_from_array(
                    page_image,
                    pattern=self._config.check_pattern,
                    region=self._config.get('ocr_region_top')
                )

                # 嘗試辨識下半部支票（一頁兩張的情況）
                bottom_number = ocr_engine.extract_from_array(
                    page_image,
                    pattern=self._config.check_pattern,
                    region=self._config.get('ocr_region_bottom')
                )

                # 判斷是否有找到號碼
                found_any = False

                if top_number:
                    position = 'top' if bottom_number else 'full'
                    entry = CheckEntry(
                        file=pdf_name,
                        page=page_idx,
                        position=position,
                        raw_ocr=top_number
                    )
                    self._add_entry(top_number, entry)
                    count += 1
                    found_any = True

                if bottom_number and bottom_number != top_number:
                    entry = CheckEntry(
                        file=pdf_name,
                        page=page_idx,
                        position='bottom',
                        raw_ocr=bottom_number
                    )
                    self._add_entry(bottom_number, entry)
                    count += 1
                    found_any = True

                if not found_any:
                    unrecognized_pages.append(page_idx)

            # 記錄 PDF 元資料
            self._pdf_meta[pdf_name] = {
                'mtime': mtime,
                'page_count': total_pages,
                'indexed_at': datetime.now().isoformat(),
                'check_count': count,
            }
            self._unrecognized[pdf_name] = unrecognized_pages

        finally:
            doc.close()

        if unrecognized_pages:
            logger.warning(
                f"{pdf_name}: {len(unrecognized_pages)} 頁無法辨識支票號碼"
                f"（頁碼: {unrecognized_pages[:5]}{'...' if len(unrecognized_pages) > 5 else ''}）"
            )

        return count

    def _render_page(self, doc: fitz.Document, page_idx: int, dpi: int) -> Optional[np.ndarray]:
        """將 PDF 頁面渲染為 numpy array"""
        try:
            page = doc[page_idx]
            mat = fitz.Matrix(dpi / 72, dpi / 72)
            pix = page.get_pixmap(matrix=mat, colorspace=fitz.csRGB)
            # 轉換為 numpy array
            img_array = np.frombuffer(pix.samples, dtype=np.uint8)
            img_array = img_array.reshape(pix.height, pix.width, 3)
            return img_array
        except Exception as e:
            logger.error(f"渲染頁面 {page_idx} 失敗: {e}")
            return None

    def render_check_image(
        self,
        entry: CheckEntry,
        dpi: int = 200
    ) -> Optional[Image.Image]:
        """
        渲染指定支票為 PIL Image（用於預覽/列印）
        
        Args:
            entry: CheckEntry 記錄
            dpi: 解析度（預覽用 200，列印用 300）
        
        Returns:
            PIL Image（已根據 position 裁切），或 None
        """
        pdf_dir = self._config.pdf_dir
        if not pdf_dir:
            return None

        pdf_path = pdf_dir / entry.file
        if not pdf_path.exists():
            logger.error(f"找不到 PDF: {pdf_path}")
            return None

        try:
            doc = fitz.open(str(pdf_path))
            try:
                if entry.page >= doc.page_count:
                    logger.error(f"頁碼超出範圍: {entry.page} >= {doc.page_count}")
                    return None

                page = doc[entry.page]
                mat = fitz.Matrix(dpi / 72, dpi / 72)
                pix = page.get_pixmap(matrix=mat, colorspace=fitz.csRGB)
                img = Image.frombytes('RGB', [pix.width, pix.height], pix.samples)

                # 根據位置裁切
                img = self._crop_by_position(img, entry.position)
                return img

            finally:
                doc.close()

        except Exception as e:
            logger.error(f"渲染支票圖片失敗: {e}")
            return None

    def _crop_by_position(self, img: Image.Image, position: str) -> Image.Image:
        """根據支票位置裁切圖片"""
        w, h = img.size
        if position == 'top':
            return img.crop((0, 0, w, h // 2))
        elif position == 'bottom':
            return img.crop((0, h // 2, w, h))
        else:  # 'full'
            return img

    def _add_entry(self, check_number: str, entry: CheckEntry):
        """新增或更新索引記錄"""
        key = check_number.upper()
        if key not in self._master:
            self._master[key] = []

        # 避免重複（同一 PDF 同一頁同一位置）
        existing = self._master[key]
        for i, e in enumerate(existing):
            if e.file == entry.file and e.page == entry.page and e.position == entry.position:
                existing[i] = entry  # 更新
                return
        existing.append(entry)

    def _remove_pdf_from_index(self, pdf_name: str):
        """從索引中移除指定 PDF 的所有記錄"""
        keys_to_remove = []
        for check_num, entries in self._master.items():
            self._master[check_num] = [e for e in entries if e.file != pdf_name]
            if not self._master[check_num]:
                keys_to_remove.append(check_num)

        for key in keys_to_remove:
            del self._master[key]

        self._pdf_meta.pop(pdf_name, None)
        self._unrecognized.pop(pdf_name, None)
        logger.info(f"已從索引移除: {pdf_name}")
