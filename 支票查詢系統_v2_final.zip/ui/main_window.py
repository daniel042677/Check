"""
主視窗
整合所有功能的主要 UI 介面

版面配置：
┌─────────────────────────────────────────────────────────┐
│  [標題] 支票查詢系統          [設定] [重建索引] [關於]   │
├────────────────────┬────────────────────────────────────┤
│  搜尋區域          │  預覽區域                          │
│  [輸入框] [搜尋]   │                                    │
│                    │    （支票圖片預覽）                 │
│  搜尋結果列表      │                                    │
│  ┌──────────────┐  │                                    │
│  │ 結果1        │  │                                    │
│  │ 結果2        │  │                                    │
│  └──────────────┘  │                                    │
│                    │                                    │
│  [預覽]  [列印]    │                                    │
├────────────────────┴────────────────────────────────────┤
│  狀態列：已索引 N 張支票 | 最後更新: 2026-03-20         │
└─────────────────────────────────────────────────────────┘
"""
import logging
from pathlib import Path
from typing import Optional, List

from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QListWidget, QListWidgetItem,
    QSplitter, QStatusBar, QMessageBox, QProgressDialog,
    QGroupBox, QScrollArea, QApplication, QCompleter,
    QFrame, QSizePolicy
)
from PyQt6.QtGui import QPixmap, QIcon, QKeySequence, QFont, QAction, QColor
from PyQt6.QtCore import Qt, QSize, QThread, QStringListModel, pyqtSlot

from config import get_config
from core.ocr_engine import OCREngine
from core.indexer import Indexer
from core.searcher import Searcher, SearchResult
from core.printer import PrintManager, pil_to_qpixmap
from ui.workers import IndexWorker
from ui.settings_dialog import SettingsDialog

logger = logging.getLogger(__name__)


class PreviewWidget(QScrollArea):
    """支票圖片預覽區域（可滾動、可縮放）"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setMinimumWidth(400)

        self._lbl = QLabel("請在左側搜尋並選擇支票")
        self._lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._lbl.setStyleSheet("color: #bbb; font-size: 14pt;")
        self._lbl.setWordWrap(True)
        self.setWidget(self._lbl)
        self.setWidgetResizable(True)

        self._original_pixmap: Optional[QPixmap] = None

    def set_image(self, pixmap: QPixmap):
        """設定要顯示的圖片"""
        self._original_pixmap = pixmap
        self._lbl.setStyleSheet("")
        self._update_display()

    def clear(self):
        """清除圖片"""
        self._original_pixmap = None
        self._lbl.setPixmap(QPixmap())
        self._lbl.setText("請在左側搜尋並選擇支票")
        self._lbl.setStyleSheet("color: #bbb; font-size: 14pt;")

    def _update_display(self):
        if self._original_pixmap is None:
            return
        available = self.viewport().size()
        scaled = self._original_pixmap.scaled(
            available,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation
        )
        self._lbl.setPixmap(scaled)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._update_display()


class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()
        self._config = get_config()
        self._ocr = OCREngine()
        self._indexer = Indexer(self._config)
        self._searcher = Searcher(self._indexer)
        self._printer = PrintManager(self)
        self._worker: Optional[IndexWorker] = None
        self._current_results: List[SearchResult] = []
        self._current_check_image = None  # PIL Image

        self.setWindowTitle("支票查詢系統 v1.0")
        self.setMinimumSize(900, 600)

        self._build_ui()
        self._build_menu()
        self._restore_geometry()

        # 延遲到 show() 之後才執行，避免在視窗尚未顯示時彈出 modal dialog
        from PyQt6.QtCore import QTimer
        QTimer.singleShot(100, self._on_startup)

    # ─── UI 建構 ─────────────────────────────────────────

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(8, 8, 8, 4)
        main_layout.setSpacing(8)

        # 主分割器
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setObjectName("main_splitter")
        main_layout.addWidget(splitter)

        # ── 左側面板 ──
        left_panel = self._build_left_panel()
        splitter.addWidget(left_panel)

        # ── 右側預覽面板 ──
        right_panel = self._build_right_panel()
        splitter.addWidget(right_panel)

        splitter.setSizes([360, 600])
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)

        self._splitter = splitter

        # 狀態列
        self._build_status_bar()

    def _build_left_panel(self) -> QWidget:
        panel = QWidget()
        panel.setMaximumWidth(400)
        panel.setMinimumWidth(280)
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(0, 0, 4, 0)
        layout.setSpacing(8)

        # 搜尋群組
        search_group = QGroupBox("搜尋支票")
        search_layout = QVBoxLayout(search_group)
        search_layout.setSpacing(6)

        # 搜尋輸入框
        search_row = QHBoxLayout()
        self._txt_search = QLineEdit()
        self._txt_search.setPlaceholderText("輸入支票號碼（如 HF1377789 或 1377）")
        self._txt_search.setMinimumHeight(36)
        self._txt_search.returnPressed.connect(self._do_search)
        self._txt_search.textChanged.connect(self._on_search_text_changed)
        search_row.addWidget(self._txt_search)

        self._btn_search = QPushButton("搜尋")
        self._btn_search.setObjectName("btn_primary")
        self._btn_search.setMinimumHeight(36)
        self._btn_search.setFixedWidth(70)
        self._btn_search.clicked.connect(self._do_search)
        self._btn_search.setShortcut(QKeySequence("Return"))
        search_row.addWidget(self._btn_search)
        search_layout.addLayout(search_row)

        # 搜尋提示
        lbl_hint = QLabel("💡 支援模糊搜尋（輸入部分號碼即可）")
        lbl_hint.setStyleSheet("color: #888; font-size: 9pt;")
        search_layout.addWidget(lbl_hint)
        layout.addWidget(search_group)

        # 搜尋結果
        result_group = QGroupBox("搜尋結果")
        result_layout = QVBoxLayout(result_group)
        result_layout.setSpacing(4)

        self._lbl_result_count = QLabel("尚未搜尋")
        self._lbl_result_count.setStyleSheet("color: #888; font-size: 9pt;")
        result_layout.addWidget(self._lbl_result_count)

        self._list_results = QListWidget()
        self._list_results.setMinimumHeight(200)
        self._list_results.itemSelectionChanged.connect(self._on_result_selected)
        self._list_results.itemDoubleClicked.connect(self._on_result_double_clicked)
        result_layout.addWidget(self._list_results)
        layout.addWidget(result_group)

        # 操作按鈕
        btn_layout = QHBoxLayout()

        self._btn_preview = QPushButton("🔍 預覽")
        self._btn_preview.setEnabled(False)
        self._btn_preview.setMinimumHeight(34)
        self._btn_preview.clicked.connect(self._do_preview)
        btn_layout.addWidget(self._btn_preview)

        self._btn_print = QPushButton("🖨 列印支票")
        self._btn_print.setObjectName("btn_print")
        self._btn_print.setEnabled(False)
        self._btn_print.setMinimumHeight(34)
        self._btn_print.clicked.connect(self._do_print)
        btn_layout.addWidget(self._btn_print)
        layout.addLayout(btn_layout)

        # 選中支票詳細資訊
        self._lbl_detail = QLabel("")
        self._lbl_detail.setStyleSheet(
            "color: #555; font-size: 9pt; padding: 6px; "
            "background: #fafafa; border: 1px solid #eee; border-radius: 3px;"
        )
        self._lbl_detail.setWordWrap(True)
        self._lbl_detail.hide()
        layout.addWidget(self._lbl_detail)

        layout.addStretch()
        return panel

    def _build_right_panel(self) -> QWidget:
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(4, 0, 0, 0)
        layout.setSpacing(4)

        # 預覽標題
        title_row = QHBoxLayout()
        lbl_preview_title = QLabel("支票預覽")
        lbl_preview_title.setStyleSheet("font-weight: bold; font-size: 11pt;")
        title_row.addWidget(lbl_preview_title)

        self._lbl_check_number = QLabel("")
        self._lbl_check_number.setStyleSheet(
            "color: #1890ff; font-size: 13pt; font-weight: bold;"
        )
        title_row.addWidget(self._lbl_check_number, 1)
        layout.addLayout(title_row)

        # 分隔線
        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        line.setStyleSheet("color: #e8e8e8;")
        layout.addWidget(line)

        # 預覽區域
        self._preview = PreviewWidget()
        layout.addWidget(self._preview, 1)

        return panel

    def _build_menu(self):
        """建立選單列"""
        menubar = self.menuBar()

        # 功能選單
        menu_file = menubar.addMenu("功能(&F)")

        act_rebuild = QAction("🔄 重新建立索引（全部）", self)
        act_rebuild.setShortcut(QKeySequence("Ctrl+R"))
        act_rebuild.triggered.connect(self._rebuild_index_full)
        menu_file.addAction(act_rebuild)

        act_update = QAction("⚡ 更新索引（只掃新增 PDF）", self)
        act_update.setShortcut(QKeySequence("Ctrl+U"))
        act_update.triggered.connect(self._rebuild_index_incremental)
        menu_file.addAction(act_update)

        menu_file.addSeparator()

        act_settings = QAction("⚙ 設定...", self)
        act_settings.setShortcut(QKeySequence("Ctrl+,"))
        act_settings.triggered.connect(self._open_settings)
        menu_file.addAction(act_settings)

        menu_file.addSeparator()

        act_quit = QAction("離開", self)
        act_quit.setShortcut(QKeySequence("Alt+F4"))
        act_quit.triggered.connect(self.close)
        menu_file.addAction(act_quit)

        # 說明選單
        menu_help = menubar.addMenu("說明(&H)")

        act_about = QAction("關於", self)
        act_about.triggered.connect(self._show_about)
        menu_help.addAction(act_about)

    def _build_status_bar(self):
        self._statusbar = self.statusBar()

        self._lbl_status_checks = QLabel("索引尚未載入")
        self._lbl_status_checks.setStyleSheet("margin-right: 20px;")
        self._statusbar.addWidget(self._lbl_status_checks)

        self._lbl_status_folder = QLabel("")
        self._lbl_status_folder.setStyleSheet("color: #888;")
        self._statusbar.addWidget(self._lbl_status_folder, 1)

        self._lbl_status_ready = QLabel("就緒")
        self._statusbar.addPermanentWidget(self._lbl_status_ready)

    def _restore_geometry(self):
        """還原上次的視窗大小和位置"""
        geo = self._config.get('window_geometry')
        if geo:
            try:
                from PyQt6.QtCore import QByteArray
                self.restoreGeometry(QByteArray.fromHex(geo.encode()))
            except Exception:
                pass

    # ─── 啟動邏輯 ──────────────────────────────────────

    def _on_startup(self):
        """程式啟動後的初始化流程"""
        # 若尚未設定共用資料夾，先引導使用者設定
        if not self._config.shared_folder:
            QMessageBox.information(
                self,
                "歡迎使用支票查詢系統",
                "首次使用，請先設定共用資料夾路徑。\n\n"
                "請在接下來的設定畫面中填入存放支票 PDF 的網路共用資料夾路徑。"
            )
            self._open_settings()
            if not self._config.shared_folder:
                return

        # 載入既有索引
        self._load_existing_index()

    def _load_existing_index(self):
        """載入既有索引，並掃描是否有新 PDF"""
        count = self._indexer.load()
        self._update_status()

        if count == 0:
            # 沒有既有索引，需要全量建立
            reply = QMessageBox.question(
                self,
                "首次建立索引",
                f"尚無支票索引資料。\n\n"
                f"需要掃描 PDF 資料夾並建立索引，\n"
                f"此過程依 PDF 數量可能需要數分鐘至數十分鐘。\n\n"
                f"現在開始建立嗎？",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply == QMessageBox.StandardButton.Yes:
                self._start_indexing('full')
        else:
            # 有既有索引，背景掃描是否有新 PDF
            new_pdfs = self._indexer.get_new_pdfs()
            if new_pdfs:
                self._statusbar.showMessage(
                    f"發現 {len(new_pdfs)} 個新增或更新的 PDF，正在更新索引...", 3000
                )
                self._start_indexing('incremental')

    # ─── 索引建立 ──────────────────────────────────────

    def _start_indexing(self, mode: str):
        """啟動背景索引建立"""
        if self._worker and self._worker.isRunning():
            QMessageBox.warning(self, "提示", "索引建立正在進行中，請稍候")
            return

        if not self._config.shared_folder:
            QMessageBox.warning(self, "設定不完整", "請先在設定中填入共用資料夾路徑")
            return

        # 建立進度對話框
        self._progress_dialog = QProgressDialog(
            "正在初始化...", "取消", 0, 100, self
        )
        self._progress_dialog.setWindowTitle(
            "全量建立索引" if mode == 'full' else "更新索引"
        )
        self._progress_dialog.setWindowModality(Qt.WindowModality.WindowModal)
        self._progress_dialog.setMinimumDuration(0)
        self._progress_dialog.setAutoClose(False)
        self._progress_dialog.setAutoReset(False)
        self._progress_dialog.setValue(0)

        # 建立並啟動工作執行緒
        self._worker = IndexWorker(self._indexer, self._ocr, self._config, mode)
        self._worker.progress.connect(self._on_index_progress)
        self._worker.finished.connect(self._on_index_finished)
        self._worker.ocr_failed.connect(self._on_ocr_failed)

        # 取消按鈕
        self._progress_dialog.canceled.connect(self._worker.cancel)

        self._worker.start()
        self._progress_dialog.show()
        self._btn_search.setEnabled(False)
        self._lbl_status_ready.setText("索引建立中...")

    @pyqtSlot(int, int, str)
    def _on_index_progress(self, current: int, total: int, message: str):
        """索引進度更新"""
        if total > 0:
            pct = int(current / total * 100)
        else:
            pct = 0
        if hasattr(self, '_progress_dialog'):
            self._progress_dialog.setValue(pct)
            self._progress_dialog.setLabelText(message)

    @pyqtSlot(int, int, list)
    def _on_index_finished(self, new_checks: int, pdf_count: int, errors: list):
        """索引建立完成"""
        if hasattr(self, '_progress_dialog'):
            self._progress_dialog.close()

        self._btn_search.setEnabled(True)
        self._lbl_status_ready.setText("就緒")
        self._update_status()

        # 顯示完成訊息
        if errors:
            error_text = '\n'.join(errors[:10])
            if len(errors) > 10:
                error_text += f"\n...（共 {len(errors)} 個錯誤）"
            QMessageBox.warning(
                self, "索引建立完成（含警告）",
                f"已新增 {new_checks} 筆支票，共處理 {pdf_count} 個 PDF。\n\n"
                f"以下 PDF 無法完整處理：\n{error_text}"
            )
        else:
            stats = self._indexer.get_stats()
            self._statusbar.showMessage(
                f"索引更新完成！目前共 {stats['total_checks']} 張支票，"
                f"{stats['total_pdfs']} 個 PDF", 5000
            )

    @pyqtSlot(str)
    def _on_ocr_failed(self, error_msg: str):
        """OCR 引擎初始化失敗"""
        if hasattr(self, '_progress_dialog'):
            self._progress_dialog.close()
        self._btn_search.setEnabled(True)
        self._lbl_status_ready.setText("就緒")

        QMessageBox.critical(
            self, "OCR 引擎錯誤",
            f"無法初始化 OCR 引擎：\n\n{error_msg}\n\n"
            "請確認：\n"
            "1. 電腦可以連上網際網路（首次使用需下載 OCR 模型）\n"
            "2. 已安裝所有必要的套件（執行 install.bat）\n"
            "3. 防毒軟體未封鎖程式"
        )

    def _rebuild_index_full(self):
        """選單：全量重建索引"""
        reply = QMessageBox.question(
            self, "全量重建索引",
            "確定要重新掃描所有 PDF 嗎？\n\n"
            "此操作會清除現有索引，依 PDF 數量可能需要較長時間。",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            # 清除現有索引（強制重掃）
            self._indexer._master.clear()
            self._indexer._pdf_meta.clear()
            self._indexer._unrecognized.clear()
            self._start_indexing('full')

    def _rebuild_index_incremental(self):
        """選單：只掃新增 PDF"""
        self._start_indexing('incremental')

    # ─── 搜尋邏輯 ──────────────────────────────────────

    def _on_search_text_changed(self, text: str):
        """輸入框文字變更時的即時搜尋（可選）"""
        # 超過3個字元時才即時搜尋（避免太頻繁）
        if len(text) >= 3:
            self._do_search(silent=True)

    def _do_search(self, silent: bool = False):
        """執行搜尋"""
        query = self._txt_search.text().strip()
        if not query:
            return

        if self._indexer.total_checks == 0:
            if not silent:
                QMessageBox.information(self, "索引未建立",
                                        "支票索引尚未建立或尚未載入。\n請等待索引建立完成後再搜尋。")
            return

        results = self._searcher.search(query)
        self._current_results = results
        self._display_results(results)

        # 儲存搜尋歷史
        if not silent and results:
            self._config.add_search_history(query)

    def _display_results(self, results: List[SearchResult]):
        """顯示搜尋結果列表"""
        self._list_results.clear()
        self._btn_preview.setEnabled(False)
        self._btn_print.setEnabled(False)
        self._lbl_detail.hide()
        self._preview.clear()
        self._lbl_check_number.setText("")

        if not results:
            self._lbl_result_count.setText("找不到符合的支票")
            item = QListWidgetItem("⚠ 找不到此支票號碼")
            item.setForeground(QColor('#ff4d4f'))
            self._list_results.addItem(item)
            return

        self._lbl_result_count.setText(f"找到 {len(results)} 筆結果")

        for i, result in enumerate(results):
            item = QListWidgetItem()
            # 多行顯示
            pos_map = {'full': '整頁', 'top': '上半頁', 'bottom': '下半頁'}
            pos_text = pos_map.get(result.entry.position, result.entry.position)
            item.setText(
                f"🏷 {result.check_number}\n"
                f"   📄 {result.entry.file}  |  第 {result.entry.page + 1} 頁 {pos_text}"
            )
            item.setData(Qt.ItemDataRole.UserRole, i)
            self._list_results.addItem(item)

        # 如果只有一個結果，自動選中
        if len(results) == 1:
            self._list_results.setCurrentRow(0)

    def _on_result_selected(self):
        """使用者選取搜尋結果"""
        items = self._list_results.selectedItems()
        if not items:
            return

        idx = items[0].data(Qt.ItemDataRole.UserRole)
        if idx is None or idx >= len(self._current_results):
            return

        result = self._current_results[idx]

        # 顯示詳細資訊
        self._lbl_detail.setText(result.detail_text)
        self._lbl_detail.show()

        # 載入預覽圖片
        self._load_preview(result)

        # 啟用按鈕
        self._btn_preview.setEnabled(True)
        self._btn_print.setEnabled(True)
        self._lbl_check_number.setText(result.check_number)

    def _on_result_double_clicked(self, item: QListWidgetItem):
        """雙擊直接列印"""
        self._do_print()

    def _load_preview(self, result: SearchResult):
        """載入並顯示支票預覽圖"""
        self._preview.clear()
        self._current_check_image = None

        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            img = self._indexer.render_check_image(
                result.entry,
                dpi=self._config.preview_dpi
            )
            if img:
                self._current_check_image = img
                pixmap = pil_to_qpixmap(img)
                self._preview.set_image(pixmap)
            else:
                self._preview.clear()
                QMessageBox.warning(
                    self, "預覽失敗",
                    f"無法載入支票圖片。\n\n"
                    f"請確認檔案仍存在：{result.entry.file}\n"
                    f"路徑：{self._config.pdf_dir}"
                )
        finally:
            QApplication.restoreOverrideCursor()

    # ─── 預覽和列印 ────────────────────────────────────

    def _do_preview(self):
        """（點選預覽按鈕，圖片已顯示在右側，此按鈕確保圖片已載入）"""
        items = self._list_results.selectedItems()
        if items:
            self._on_result_selected()

    def _do_print(self):
        """列印支票"""
        if self._current_check_image is None:
            QMessageBox.warning(self, "列印", "請先選擇一張支票")
            return

        items = self._list_results.selectedItems()
        if not items:
            return
        idx = items[0].data(Qt.ItemDataRole.UserRole)
        if idx is None or idx >= len(self._current_results):
            return

        result = self._current_results[idx]

        # 取得高解析度版本用於列印
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            print_img = self._indexer.render_check_image(
                result.entry,
                dpi=self._config.print_dpi
            )
        finally:
            QApplication.restoreOverrideCursor()

        if print_img is None:
            QMessageBox.critical(self, "列印錯誤", "無法取得列印品質的支票圖片")
            return

        # 顯示列印預覽
        printed = self._printer.print_check(print_img, result.check_number)
        if printed:
            self._statusbar.showMessage(
                f"已傳送列印：{result.check_number}", 3000
            )

    # ─── 其他功能 ───────────────────────────────────────

    def _open_settings(self):
        """開啟設定對話框"""
        dlg = SettingsDialog(self._config, self)
        if dlg.exec():
            self._update_status()
            # 設定變更後，若共用資料夾有變，需要重新載入索引
            self._indexer._master.clear()
            self._indexer._pdf_meta.clear()
            count = self._indexer.load()
            if count == 0 and self._config.shared_folder:
                reply = QMessageBox.question(
                    self, "建立索引",
                    "設定已更新。\n需要現在建立索引嗎？",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
                )
                if reply == QMessageBox.StandardButton.Yes:
                    self._start_indexing('full')
            self._update_status()

    def _show_about(self):
        QMessageBox.about(
            self, "關於支票查詢系統",
            "<h3>支票查詢系統 v1.0</h3>"
            "<p>用於查詢實體支票掃描檔案的系統</p>"
            "<hr>"
            "<p><b>功能說明：</b><br>"
            "• 自動 OCR 辨識支票號碼並建立索引<br>"
            "• 支援一頁一張或一頁兩張的支票格式<br>"
            "• 精確及模糊搜尋支票號碼<br>"
            "• 預覽後列印（只印支票半頁）</p>"
            "<hr>"
            "<p><b>使用技巧：</b><br>"
            "• 首次使用需建立索引（可能需數分鐘）<br>"
            "• 新增 PDF 後請執行「更新索引」<br>"
            "• 可輸入部分號碼進行模糊搜尋</p>"
        )

    def _update_status(self):
        """更新狀態列"""
        stats = self._indexer.get_stats()
        self._lbl_status_checks.setText(
            f"📋 已索引 {stats['total_checks']:,} 張支票  "
            f"（{stats['total_pdfs']} 個 PDF）"
        )
        if self._config.shared_folder:
            self._lbl_status_folder.setText(
                f"📁 {self._config.shared_folder}"
            )
        else:
            self._lbl_status_folder.setText("⚠ 尚未設定共用資料夾")

    # ─── 視窗事件 ──────────────────────────────────────

    def closeEvent(self, event):
        """關閉視窗時儲存狀態"""
        # 儲存視窗幾何
        self._config.set(
            'window_geometry',
            self.saveGeometry().toHex().data().decode()
        )
        # 若有背景執行緒正在運作，詢問是否取消
        if self._worker and self._worker.isRunning():
            reply = QMessageBox.question(
                self, "確認關閉",
                "索引建立仍在進行中，確定要關閉嗎？",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply == QMessageBox.StandardButton.No:
                event.ignore()
                return
            self._worker.cancel()
            self._worker.wait(3000)
        event.accept()
